import { SchemaDefinition, DataRecord, FieldDefinition } from '../types/dataEntry';

export function validateFieldValue(field: FieldDefinition, value: any): string | null {
  if (field.required) {
    if (value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0)) {
      return `${field.label} is required`;
    }
  }

  if (value === undefined || value === null || value === '') {
    return null; // Empty optional field is okay
  }

  if (field.type === 'number' || field.type === 'currency') {
    const num = Number(value);
    if (isNaN(num)) {
      return `${field.label} must be a valid number`;
    }
    if (field.min !== undefined && num < field.min) {
      return `${field.label} must be at least ${field.min}`;
    }
    if (field.max !== undefined && num > field.max) {
      return `${field.label} must be at most ${field.max}`;
    }
  }

  if (field.validationRule === 'email' || field.type === 'email') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(String(value).trim())) {
      return 'Enter a valid email address';
    }
  }

  if (field.validationRule === 'phone') {
    const phoneClean = String(value).replace(/[\s\-\(\)\+\.]/g, '');
    if (phoneClean.length < 7) {
      return 'Enter a valid phone number';
    }
  }

  if (field.validationRule === 'positive_number') {
    const num = Number(value);
    if (isNaN(num) || num <= 0) {
      return 'Must be greater than 0';
    }
  }

  if (field.validationRule === 'sku_code') {
    if (String(value).trim().length < 2) {
      return 'Code must be at least 2 characters';
    }
  }

  return null;
}

export function validateRecord(schema: SchemaDefinition, data: Record<string, any>): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const field of schema.fields) {
    const err = validateFieldValue(field, data[field.id]);
    if (err) {
      errors[field.id] = err;
    }
  }
  return errors;
}

/**
 * Converts records to RFC 4180 CSV
 */
export function exportToCSV(schema: SchemaDefinition, records: DataRecord[]): string {
  const headers = ['Record_ID', 'Created_At', ...schema.fields.map(f => f.label)];
  
  const escapeCell = (val: any): string => {
    if (val === null || val === undefined) return '""';
    const str = String(val);
    if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return `"${str}"`;
  };

  const rows = records.map(r => {
    const fieldCells = schema.fields.map(f => escapeCell(r.data[f.id]));
    return [escapeCell(r.id), escapeCell(r.createdAt), ...fieldCells].join(',');
  });

  return [headers.map(escapeCell).join(','), ...rows].join('\r\n');
}

/**
 * Downloads a text/csv/json file to client machine
 */
export function downloadFile(content: string, fileName: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Parse raw CSV string into rows with RFC 4180 handling
 */
export function parseCSV(csvText: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentCell = '';
  let insideQuotes = false;

  for (let i = 0; i < csvText.length; i++) {
    const char = csvText[i];
    const nextChar = csvText[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        currentCell += '"';
        i++; // skip escaped quote
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === ',' && !insideQuotes) {
      currentRow.push(currentCell.trim());
      currentCell = '';
    } else if ((char === '\r' || char === '\n') && !insideQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      currentRow.push(currentCell.trim());
      currentCell = '';
      if (currentRow.some(c => c.length > 0)) {
        rows.push(currentRow);
      }
      currentRow = [];
    } else {
      currentCell += char;
    }
  }

  if (currentCell.length > 0 || currentRow.length > 0) {
    currentRow.push(currentCell.trim());
    if (currentRow.some(c => c.length > 0)) {
      rows.push(currentRow);
    }
  }

  return rows;
}
