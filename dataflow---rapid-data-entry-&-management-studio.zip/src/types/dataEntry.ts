export type FieldType = 
  | 'text' 
  | 'number' 
  | 'currency' 
  | 'date' 
  | 'select' 
  | 'email' 
  | 'phone' 
  | 'checkbox' 
  | 'rating' 
  | 'textarea' 
  | 'tags';

export interface FieldDefinition {
  id: string;
  label: string;
  type: FieldType;
  required: boolean;
  placeholder?: string;
  defaultValue?: any;
  options?: string[]; // for 'select' or 'tags'
  prefix?: string;    // e.g. '$', '€'
  suffix?: string;    // e.g. 'kg', 'pcs', '%'
  min?: number;
  max?: number;
  stickyDefault?: boolean; // persists across consecutive records
  validationRule?: 'none' | 'email' | 'phone' | 'positive_number' | 'sku_code';
  helperText?: string;
}

export interface SchemaDefinition {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  fields: FieldDefinition[];
  primaryFieldId: string; // Used as record title/identifier
}

export interface DataRecord {
  id: string;
  schemaId: string;
  createdAt: string;
  updatedAt: string;
  data: Record<string, any>;
  flagged?: boolean;
}

export type ViewMode = 'form' | 'batch' | 'grid';

export interface BatchSessionStats {
  isActive: boolean;
  startTime: number | null;
  targetCount: number;
  recordsAddedInSession: number;
  totalKeystrokes: number;
}
