/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SchemaDefinition, DataRecord, ViewMode } from './types/dataEntry';
import { DEFAULT_SCHEMAS, INITIAL_RECORDS } from './data/defaultSchemas';
import { Header } from './components/Header';
import { RapidFormView } from './components/RapidFormView';
import { KeypunchBatchView } from './components/KeypunchBatchView';
import { GridView } from './components/GridView';
import { SchemaEditorModal } from './components/SchemaEditorModal';
import { CsvImportModal } from './components/CsvImportModal';
import { ExportModal } from './components/ExportModal';
import { DataHygieneModal } from './components/DataHygieneModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { downloadFile, exportToCSV } from './utils/exportImport';
import { playSound } from './utils/audio';

const STORAGE_KEY_SCHEMAS = 'dataflow_schemas_v2';
const STORAGE_KEY_RECORDS = 'dataflow_records_v2';
const STORAGE_KEY_ACTIVE_SCHEMA = 'dataflow_active_schema_v2';
const STORAGE_KEY_SOUND = 'dataflow_sound_enabled';

export default function App() {
  // Load initial schemas & records with fallback to default templates
  const [schemas, setSchemas] = useState<SchemaDefinition[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SCHEMAS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return DEFAULT_SCHEMAS;
  });

  const [activeSchemaId, setActiveSchemaId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_SCHEMA);
      if (saved) return saved;
    } catch {}
    return 'inventory';
  });

  const [records, setRecords] = useState<DataRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_RECORDS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_RECORDS;
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SOUND);
      if (saved !== null) return JSON.parse(saved);
    } catch {}
    return true;
  });

  const [viewMode, setViewMode] = useState<ViewMode>('form');
  const [sessionRecordCount, setSessionRecordCount] = useState<number>(0);

  // Modal open states
  const [isSchemaEditorOpen, setIsSchemaEditorOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isHygieneModalOpen, setIsHygieneModalOpen] = useState(false);
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState(false);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SCHEMAS, JSON.stringify(schemas));
    } catch {}
  }, [schemas]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_RECORDS, JSON.stringify(records));
    } catch {}
  }, [records]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ACTIVE_SCHEMA, activeSchemaId);
    } catch {}
  }, [activeSchemaId]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SOUND, JSON.stringify(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  // Global Keyboard Navigation
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // If typing inside an input or textarea, don't trigger global single-key shortcuts
      const isInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName);

      if (e.key === '?' && !isInput) {
        e.preventDefault();
        setIsShortcutsModalOpen(prev => !prev);
        return;
      }

      if (e.altKey && e.key === '1') {
        e.preventDefault();
        setViewMode('form');
      } else if (e.altKey && e.key === '2') {
        e.preventDefault();
        setViewMode('batch');
      } else if (e.altKey && e.key === '3') {
        e.preventDefault();
        setViewMode('grid');
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  const activeSchema = schemas.find(s => s.id === activeSchemaId) || schemas[0];
  const activeRecords = records.filter(r => r.schemaId === activeSchema.id);

  // Record CRUD Handlers
  const handleSaveRecord = (recordData: Record<string, any>) => {
    const newRecord: DataRecord = {
      id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      schemaId: activeSchema.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      data: recordData,
    };

    setRecords(prev => [newRecord, ...prev]);
    setSessionRecordCount(prev => prev + 1);
  };

  const handleUpdateRecord = (id: string, updatedData: Record<string, any>) => {
    setRecords(prev =>
      prev.map(r =>
        r.id === id
          ? { ...r, data: updatedData, updatedAt: new Date().toISOString() }
          : r
      )
    );
  };

  const handleDeleteRecord = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
    playSound('delete', soundEnabled);
  };

  const handleDeleteBulk = (ids: string[]) => {
    const setIds = new Set(ids);
    setRecords(prev => prev.filter(r => !setIds.has(r.id)));
    playSound('delete', soundEnabled);
  };

  const handleDuplicateRecord = (record: DataRecord) => {
    const cloned: DataRecord = {
      ...record,
      id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      data: { ...record.data },
    };
    setRecords(prev => [cloned, ...prev]);
    playSound('success', soundEnabled);
  };

  const handleAddNewRow = () => {
    const blankData: Record<string, any> = {};
    activeSchema.fields.forEach(f => {
      blankData[f.id] = f.defaultValue !== undefined ? f.defaultValue : (f.type === 'checkbox' ? false : '');
    });
    handleSaveRecord(blankData);
    playSound('next', soundEnabled);
  };

  // Schema Handlers
  const handleSaveSchema = (updatedSchema: SchemaDefinition) => {
    setSchemas(prev => prev.map(s => (s.id === updatedSchema.id ? updatedSchema : s)));
    playSound('success', soundEnabled);
  };

  const handleCreateNewSchema = (newSchema: SchemaDefinition) => {
    setSchemas(prev => [...prev, newSchema]);
    setActiveSchemaId(newSchema.id);
    setViewMode('form');
    playSound('success', soundEnabled);
  };

  // Import Handlers
  const handleImportRecords = (newRecords: DataRecord[], replaceExisting: boolean) => {
    if (replaceExisting) {
      setRecords(prev => [...newRecords, ...prev.filter(r => r.schemaId !== activeSchema.id)]);
    } else {
      setRecords(prev => [...newRecords, ...prev]);
    }
    setSessionRecordCount(prev => prev + newRecords.length);
  };

  // Export Selected from Grid
  const handleExportSelected = (selectedRecords: DataRecord[]) => {
    const csv = exportToCSV(activeSchema, selectedRecords);
    const fileName = `${activeSchema.id}_selected_${new Date().toISOString().split('T')[0]}.csv`;
    downloadFile(csv, fileName, 'text/csv;charset=utf-8;');
    playSound('success', soundEnabled);
  };

  // Reset to Demo Data
  const handleResetData = () => {
    if (window.confirm('Reset all dataset entries to factory demo data? Any unsaved local edits will be reset.')) {
      setSchemas(DEFAULT_SCHEMAS);
      setActiveSchemaId('inventory');
      setRecords(INITIAL_RECORDS);
      setSessionRecordCount(0);
      playSound('complete', soundEnabled);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Application Header & Navigation */}
      <Header
        schemas={schemas}
        activeSchemaId={activeSchemaId}
        onSelectSchema={setActiveSchemaId}
        viewMode={viewMode}
        onSetViewMode={setViewMode}
        recordCount={activeRecords.length}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(prev => !prev)}
        onOpenSchemaEditor={() => setIsSchemaEditorOpen(true)}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenHygieneModal={() => setIsHygieneModalOpen(true)}
        onOpenShortcutsModal={() => setIsShortcutsModalOpen(true)}
        onResetData={handleResetData}
        sessionRecordCount={sessionRecordCount}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 pb-16">
        {viewMode === 'form' && (
          <RapidFormView
            schema={activeSchema}
            onSaveRecord={handleSaveRecord}
            recentRecords={activeRecords}
            soundEnabled={soundEnabled}
            onViewGrid={() => setViewMode('grid')}
            onDeleteRecord={handleDeleteRecord}
          />
        )}

        {viewMode === 'batch' && (
          <KeypunchBatchView
            schema={activeSchema}
            onSaveRecord={handleSaveRecord}
            soundEnabled={soundEnabled}
            onViewGrid={() => setViewMode('grid')}
          />
        )}

        {viewMode === 'grid' && (
          <GridView
            schema={activeSchema}
            records={activeRecords}
            onUpdateRecord={handleUpdateRecord}
            onDeleteRecord={handleDeleteRecord}
            onDeleteBulk={handleDeleteBulk}
            onDuplicateRecord={handleDuplicateRecord}
            onAddNewRow={handleAddNewRow}
            soundEnabled={soundEnabled}
            onExportSelected={handleExportSelected}
          />
        )}
      </main>

      {/* Modals & Dialogs */}
      <SchemaEditorModal
        isOpen={isSchemaEditorOpen}
        onClose={() => setIsSchemaEditorOpen(false)}
        activeSchema={activeSchema}
        onSaveSchema={handleSaveSchema}
        onCreateNewSchema={handleCreateNewSchema}
      />

      <CsvImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        schema={activeSchema}
        onImportRecords={handleImportRecords}
        soundEnabled={soundEnabled}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        schema={activeSchema}
        records={activeRecords}
        soundEnabled={soundEnabled}
      />

      <DataHygieneModal
        isOpen={isHygieneModalOpen}
        onClose={() => setIsHygieneModalOpen(false)}
        schema={activeSchema}
        records={activeRecords}
        onDeleteRecord={handleDeleteRecord}
      />

      <ShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
      />
    </div>
  );
}
