import React, { useState, useMemo } from 'react';
import { 
  Search, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  Trash2, 
  Copy, 
  Plus, 
  FileDown, 
  CheckSquare, 
  Square, 
  Filter, 
  X,
  Edit2,
  Check,
  ChevronDown
} from 'lucide-react';
import { SchemaDefinition, DataRecord, FieldDefinition } from '../types/dataEntry';
import { playSound } from '../utils/audio';

interface GridViewProps {
  schema: SchemaDefinition;
  records: DataRecord[];
  onUpdateRecord: (id: string, updatedData: Record<string, any>) => void;
  onDeleteRecord: (id: string) => void;
  onDeleteBulk: (ids: string[]) => void;
  onDuplicateRecord: (record: DataRecord) => void;
  onAddNewRow: () => void;
  soundEnabled: boolean;
  onExportSelected: (records: DataRecord[]) => void;
}

export const GridView: React.FC<GridViewProps> = ({
  schema,
  records,
  onUpdateRecord,
  onDeleteRecord,
  onDeleteBulk,
  onDuplicateRecord,
  onAddNewRow,
  soundEnabled,
  onExportSelected,
}) => {
  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [sortFieldId, setSortFieldId] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Inline editing state: { recordId, fieldId, value }
  const [editingCell, setEditingCell] = useState<{ recordId: string; fieldId: string; tempValue: any } | null>(null);

  // Column filter state: fieldId -> selected value
  const [columnFilter, setColumnFilter] = useState<{ fieldId: string; value: string } | null>(null);

  // Toggle sort
  const handleSort = (fieldId: string) => {
    if (sortFieldId === fieldId) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else {
        setSortFieldId(null);
        setSortDirection('asc');
      }
    } else {
      setSortFieldId(fieldId);
      setSortDirection('asc');
    }
  };

  // Filtered & Sorted records
  const filteredRecords = useMemo(() => {
    return records
      .filter(record => {
        // Global search
        if (searchTerm.trim()) {
          const term = searchTerm.toLowerCase();
          const matches = Object.values(record.data).some(val => 
            String(val).toLowerCase().includes(term)
          );
          if (!matches) return false;
        }

        // Column specific filter
        if (columnFilter && columnFilter.value) {
          if (String(record.data[columnFilter.fieldId]) !== columnFilter.value) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (!sortFieldId) return 0;
        const valA = a.data[sortFieldId];
        const valB = b.data[sortFieldId];

        if (valA === valB) return 0;
        if (valA === undefined || valA === '') return 1;
        if (valB === undefined || valB === '') return -1;

        const numA = Number(valA);
        const numB = Number(valB);

        if (!isNaN(numA) && !isNaN(numB)) {
          return sortDirection === 'asc' ? numA - numB : numB - numA;
        }

        return sortDirection === 'asc'
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      });
  }, [records, searchTerm, sortFieldId, sortDirection, columnFilter]);

  // Bulk selection handlers
  const isAllSelected = filteredRecords.length > 0 && filteredRecords.every(r => selectedIds.has(r.id));
  const isSomeSelected = filteredRecords.some(r => selectedIds.has(r.id)) && !isAllSelected;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredRecords.map(r => r.id)));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Inline edit commit
  const commitInlineEdit = () => {
    if (!editingCell) return;
    const targetRecord = records.find(r => r.id === editingCell.recordId);
    if (targetRecord) {
      onUpdateRecord(editingCell.recordId, {
        ...targetRecord.data,
        [editingCell.fieldId]: editingCell.tempValue,
      });
      playSound('next', soundEnabled);
    }
    setEditingCell(null);
  };

  const cancelInlineEdit = () => {
    setEditingCell(null);
  };

  // Summary statistics for numeric / currency columns
  const columnSummaries = useMemo(() => {
    const sums: Record<string, { sum: number; count: number; avg: number; type: string; prefix?: string }> = {};

    schema.fields.forEach(field => {
      if (field.type === 'number' || field.type === 'currency') {
        let total = 0;
        let validCount = 0;
        filteredRecords.forEach(r => {
          const val = Number(r.data[field.id]);
          if (!isNaN(val) && r.data[field.id] !== '' && r.data[field.id] !== null && r.data[field.id] !== undefined) {
            total += val;
            validCount++;
          }
        });

        sums[field.id] = {
          sum: total,
          count: validCount,
          avg: validCount > 0 ? total / validCount : 0,
          type: field.type,
          prefix: field.prefix,
        };
      }
    });

    return sums;
  }, [schema.fields, filteredRecords]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
      {/* Control Bar: Search, Column Filters, Bulk Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={`Search across all ${records.length} records...`}
            className="w-full pl-9 pr-9 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Bulk Action Controls if items selected */}
        {selectedIds.size > 0 ? (
          <div className="flex items-center gap-2 bg-cyan-950/40 border border-cyan-500/30 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-semibold text-cyan-300">
              {selectedIds.size} selected
            </span>
            <div className="h-4 w-px bg-cyan-500/30"></div>
            <button
              onClick={() => {
                const selectedList = records.filter(r => selectedIds.has(r.id));
                onExportSelected(selectedList);
              }}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition-colors"
            >
              <FileDown className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export</span>
            </button>
            <button
              onClick={() => {
                if (window.confirm(`Delete ${selectedIds.size} selected records?`)) {
                  onDeleteBulk(Array.from(selectedIds));
                  setSelectedIds(new Set());
                }
              }}
              className="px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-medium flex items-center gap-1 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            {/* Quick Filter dropdown by first select column */}
            {schema.fields.find(f => f.type === 'select') && (
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500">Filter:</span>
                <select
                  value={columnFilter?.value || ''}
                  onChange={e => {
                    const firstSelect = schema.fields.find(f => f.type === 'select');
                    if (!firstSelect) return;
                    if (e.target.value) {
                      setColumnFilter({ fieldId: firstSelect.id, value: e.target.value });
                    } else {
                      setColumnFilter(null);
                    }
                  }}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
                >
                  <option value="">All Categories / Statuses</option>
                  {schema.fields.find(f => f.type === 'select')?.options?.map(opt => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              onClick={onAddNewRow}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-semibold shadow-md shadow-cyan-500/20 flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Row</span>
            </button>
          </div>
        )}
      </div>

      {/* Spreadsheet Matrix Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto max-h-[640px]">
          <table className="w-full text-left border-collapse text-xs">
            {/* Table Header */}
            <thead className="bg-slate-950/90 sticky top-0 z-20 backdrop-blur-md border-b border-slate-800 text-slate-400 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                {/* Select All Checkbox */}
                <th className="py-3 px-3 w-10 text-center border-r border-slate-800/60">
                  <button
                    onClick={toggleSelectAll}
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {isAllSelected ? (
                      <CheckSquare className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-600" />
                    )}
                  </button>
                </th>

                {/* Primary & Defined Schema Columns */}
                {schema.fields.map(field => {
                  const isSorted = sortFieldId === field.id;

                  return (
                    <th
                      key={field.id}
                      onClick={() => handleSort(field.id)}
                      className="py-3 px-3.5 font-semibold text-slate-300 hover:text-white hover:bg-slate-800/40 cursor-pointer select-none border-r border-slate-800/60 whitespace-nowrap group transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span>{field.label}</span>
                        <span className="text-slate-500 group-hover:text-cyan-400 transition-colors">
                          {isSorted ? (
                            sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-cyan-400" /> : <ArrowDown className="w-3.5 h-3.5 text-cyan-400" />
                          ) : (
                            <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                          )}
                        </span>
                      </div>
                    </th>
                  );
                })}

                {/* Actions column */}
                <th className="py-3 px-3 w-20 text-center font-semibold text-slate-400">
                  Actions
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td
                    colSpan={schema.fields.length + 2}
                    className="py-12 text-center text-slate-500"
                  >
                    <p className="text-sm font-medium">No records match the current view criteria.</p>
                    <button
                      onClick={onAddNewRow}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add First Record</span>
                    </button>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record, rIdx) => {
                  const isSelected = selectedIds.has(record.id);

                  return (
                    <tr
                      key={record.id}
                      className={`hover:bg-slate-800/40 transition-colors group ${
                        isSelected ? 'bg-cyan-950/20' : rIdx % 2 === 1 ? 'bg-slate-900/40' : ''
                      }`}
                    >
                      {/* Row Checkbox */}
                      <td className="py-2.5 px-3 text-center border-r border-slate-800/60">
                        <button
                          onClick={() => toggleSelectRow(record.id)}
                          className="text-slate-500 hover:text-white transition-colors"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-cyan-400" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-700 group-hover:text-slate-500" />
                          )}
                        </button>
                      </td>

                      {/* Field Value Cells */}
                      {schema.fields.map(field => {
                        const rawVal = record.data[field.id];
                        const isEditingThis = editingCell?.recordId === record.id && editingCell?.fieldId === field.id;

                        if (isEditingThis) {
                          return (
                            <td
                              key={field.id}
                              className="py-1 px-2 border-r border-slate-800/60 bg-slate-950"
                            >
                              <div className="flex items-center gap-1">
                                {field.type === 'select' ? (
                                  <select
                                    autoFocus
                                    value={editingCell.tempValue}
                                    onChange={e => setEditingCell({ ...editingCell, tempValue: e.target.value })}
                                    onBlur={commitInlineEdit}
                                    onKeyDown={e => {
                                      if (e.key === 'Enter') commitInlineEdit();
                                      if (e.key === 'Escape') cancelInlineEdit();
                                    }}
                                    className="w-full bg-slate-900 text-slate-100 text-xs px-2 py-1 rounded border border-cyan-500 focus:outline-none"
                                  >
                                    {field.options?.map(opt => (
                                      <option key={opt} value={opt}>
                                        {opt}
                                      </option>
                                    ))}
                                  </select>
                                ) : field.type === 'checkbox' ? (
                                  <input
                                    type="checkbox"
                                    autoFocus
                                    checked={Boolean(editingCell.tempValue)}
                                    onChange={e => setEditingCell({ ...editingCell, tempValue: e.target.checked })}
                                    onBlur={commitInlineEdit}
                                    className="w-4 h-4 rounded text-cyan-500"
                                  />
                                ) : (
                                  <input
                                    autoFocus
                                    type={field.type === 'number' || field.type === 'currency' ? 'number' : field.type === 'date' ? 'date' : 'text'}
                                    step={field.type === 'currency' ? '0.01' : '1'}
                                    value={editingCell.tempValue}
                                    onChange={e => setEditingCell({ ...editingCell, tempValue: e.target.value })}
                                    onBlur={commitInlineEdit}
                                    onKeyDown={e => {
                                      if (e.key === 'Enter') commitInlineEdit();
                                      if (e.key === 'Escape') cancelInlineEdit();
                                    }}
                                    className="w-full bg-slate-900 text-slate-100 text-xs px-2 py-1 rounded border border-cyan-500 focus:outline-none font-mono"
                                  />
                                )}
                                <button
                                  onMouseDown={commitInlineEdit}
                                  className="p-1 rounded bg-cyan-500 text-slate-950 hover:bg-cyan-400"
                                >
                                  <Check className="w-3 h-3 font-bold" />
                                </button>
                              </div>
                            </td>
                          );
                        }

                        // Display formatted cell
                        return (
                          <td
                            key={field.id}
                            onDoubleClick={() => {
                              setEditingCell({
                                recordId: record.id,
                                fieldId: field.id,
                                tempValue: rawVal !== undefined ? rawVal : '',
                              });
                            }}
                            className="py-2.5 px-3.5 border-r border-slate-800/60 text-slate-300 max-w-[240px] truncate cursor-pointer hover:bg-slate-800/50"
                            title="Double click to edit cell"
                          >
                            {field.type === 'currency' ? (
                              <span className="font-mono text-emerald-400 tabular-nums font-medium">
                                {rawVal !== undefined && rawVal !== '' ? `$${Number(rawVal).toFixed(2)}` : '—'}
                              </span>
                            ) : field.type === 'number' ? (
                              <span className="font-mono text-cyan-300 tabular-nums">
                                {rawVal !== undefined && rawVal !== '' ? `${rawVal} ${field.suffix || ''}` : '—'}
                              </span>
                            ) : field.type === 'checkbox' ? (
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono ${
                                rawVal ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-500'
                              }`}>
                                {rawVal ? 'YES' : 'NO'}
                              </span>
                            ) : field.type === 'select' ? (
                              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-medium bg-slate-800 text-slate-200 border border-slate-700/80">
                                {String(rawVal || '—')}
                              </span>
                            ) : (
                              <span className="text-slate-200">
                                {String(rawVal !== undefined ? rawVal : '—')}
                              </span>
                            )}
                          </td>
                        );
                      })}

                      {/* Row Action Buttons */}
                      <td className="py-2.5 px-2 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => onDuplicateRecord(record)}
                            title="Duplicate Row"
                            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteRecord(record.id)}
                            title="Delete Row"
                            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>

            {/* Table Footer: Column Totals & Aggregations */}
            {filteredRecords.length > 0 && Object.keys(columnSummaries).length > 0 && (
              <tfoot className="bg-slate-950 border-t-2 border-slate-700/80 text-[11px] font-mono sticky bottom-0 z-10">
                <tr>
                  <td className="py-2.5 px-3 border-r border-slate-800/60 text-center text-slate-500 font-bold">
                    Σ
                  </td>
                  {schema.fields.map(field => {
                    const stat = columnSummaries[field.id];
                    return (
                      <td
                        key={field.id}
                        className="py-2.5 px-3.5 border-r border-slate-800/60 text-slate-400 font-medium"
                      >
                        {stat ? (
                          <div className="space-y-0.5">
                            <div className="text-white font-bold tabular-nums">
                              {stat.type === 'currency' ? `$${stat.sum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : stat.sum.toLocaleString()}
                            </div>
                            <div className="text-[10px] text-slate-500">
                              Avg: {stat.type === 'currency' ? `$${stat.avg.toFixed(2)}` : stat.avg.toFixed(1)}
                            </div>
                          </div>
                        ) : null}
                      </td>
                    );
                  })}
                  <td className="py-2.5 px-3 text-center text-slate-500 text-[10px]">
                    {filteredRecords.length} rows
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Quick Add Row Button in Table Bottom */}
        <div className="p-3 bg-slate-950/60 border-t border-slate-800/80 flex items-center justify-between">
          <button
            onClick={onAddNewRow}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-xs font-semibold text-slate-300 hover:text-cyan-400 border border-slate-700 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            <span>Add Row At Bottom</span>
          </button>

          <span className="text-xs text-slate-500">
            Showing <strong className="text-slate-300">{filteredRecords.length}</strong> of {records.length} records • Double-click any cell to edit inline
          </span>
        </div>
      </div>
    </div>
  );
};
