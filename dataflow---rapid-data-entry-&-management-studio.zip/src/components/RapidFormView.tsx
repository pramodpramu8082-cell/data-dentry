import React, { useState, useEffect, useRef } from 'react';
import { 
  Plus, 
  Copy, 
  Pin, 
  Check, 
  CornerDownLeft, 
  ArrowRight, 
  Clock, 
  Trash2, 
  Sparkles,
  AlertCircle,
  HelpCircle,
  Hash,
  DollarSign,
  Calendar,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { SchemaDefinition, DataRecord, FieldDefinition } from '../types/dataEntry';
import { validateRecord, validateFieldValue } from '../utils/exportImport';
import { playSound } from '../utils/audio';

interface RapidFormViewProps {
  schema: SchemaDefinition;
  onSaveRecord: (recordData: Record<string, any>) => void;
  recentRecords: DataRecord[];
  soundEnabled: boolean;
  onViewGrid: () => void;
  onDeleteRecord: (id: string) => void;
}

export const RapidFormView: React.FC<RapidFormViewProps> = ({
  schema,
  onSaveRecord,
  recentRecords,
  soundEnabled,
  onViewGrid,
  onDeleteRecord,
}) => {
  // Form state
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [stickyFields, setStickyFields] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [lastSavedId, setLastSavedId] = useState<string | null>(null);
  const [sessionCount, setSessionCount] = useState(0);

  // References to input elements for programmatic focus & Enter key traversal
  const inputRefs = useRef<Record<string, HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | null>>({});

  // Initialize or update default values when schema changes
  useEffect(() => {
    const initial: Record<string, any> = {};
    const stickyInit: Record<string, boolean> = {};

    schema.fields.forEach(f => {
      initial[f.id] = f.defaultValue !== undefined ? f.defaultValue : (f.type === 'checkbox' ? false : '');
      if (f.stickyDefault) {
        stickyInit[f.id] = true;
      }
    });

    setFormData(initial);
    setStickyFields(stickyInit);
    setErrors({});

    // Auto focus first input on schema load
    setTimeout(() => {
      focusFirstField();
    }, 100);
  }, [schema.id]);

  const focusFirstField = () => {
    if (schema.fields.length > 0) {
      const firstFieldId = schema.fields[0].id;
      const el = inputRefs.current[firstFieldId];
      if (el) {
        el.focus();
        if ('select' in el && typeof (el as HTMLInputElement).select === 'function') {
          (el as HTMLInputElement).select();
        }
      }
    }
  };

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormData(prev => ({ ...prev, [fieldId]: value }));
    // Clear error for field if valid
    const fieldDef = schema.fields.find(f => f.id === fieldId);
    if (fieldDef) {
      const err = validateFieldValue(fieldDef, value);
      if (!err && errors[fieldId]) {
        setErrors(prev => {
          const next = { ...prev };
          delete next[fieldId];
          return next;
        });
      }
    }
  };

  const toggleSticky = (fieldId: string) => {
    setStickyFields(prev => ({
      ...prev,
      [fieldId]: !prev[fieldId],
    }));
    playSound('next', soundEnabled);
  };

  // Handle keyboard navigation between fields
  const handleKeyDown = (e: React.KeyboardEvent, index: number, field: FieldDefinition) => {
    // Ctrl + Enter or Cmd + Enter = Save Record
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
      return;
    }

    // Enter key navigation (advance to next input field)
    if (e.key === 'Enter' && field.type !== 'textarea') {
      e.preventDefault();
      playSound('next', soundEnabled);
      if (index < schema.fields.length - 1) {
        const nextField = schema.fields[index + 1];
        const nextEl = inputRefs.current[nextField.id];
        if (nextEl) {
          nextEl.focus();
          if ('select' in nextEl && typeof (nextEl as HTMLInputElement).select === 'function') {
            (nextEl as HTMLInputElement).select();
          }
        }
      } else {
        // We are on the last field: submit the form!
        handleSubmit();
      }
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const validationErrors = validateRecord(schema, formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      playSound('error', soundEnabled);
      // Focus the first invalid field
      const firstInvalidId = Object.keys(validationErrors)[0];
      inputRefs.current[firstInvalidId]?.focus();
      return;
    }

    // Valid: save record
    onSaveRecord(formData);
    playSound('success', soundEnabled);
    setSessionCount(prev => prev + 1);
    setLastSavedId(String(formData[schema.primaryFieldId] || 'Record'));

    // Reset form: retain sticky fields, reset non-sticky fields
    const nextFormData: Record<string, any> = {};
    schema.fields.forEach(f => {
      if (stickyFields[f.id]) {
        nextFormData[f.id] = formData[f.id];
      } else {
        nextFormData[f.id] = f.defaultValue !== undefined ? f.defaultValue : (f.type === 'checkbox' ? false : '');
      }
    });

    setFormData(nextFormData);
    setErrors({});

    // Immediate focus back to first non-sticky or first field
    setTimeout(() => {
      focusFirstField();
    }, 50);
  };

  // Duplicate values from the most recent record
  const handleDuplicateLast = () => {
    if (recentRecords.length === 0) return;
    const latest = recentRecords[0];
    setFormData({ ...latest.data });
    playSound('next', soundEnabled);
    focusFirstField();
  };

  const renderFieldInput = (field: FieldDefinition, index: number) => {
    const value = formData[field.id] !== undefined ? formData[field.id] : '';
    const hasError = !!errors[field.id];

    switch (field.type) {
      case 'select':
        return (
          <select
            ref={el => { inputRefs.current[field.id] = el; }}
            value={value}
            onChange={e => handleFieldChange(field.id, e.target.value)}
            onKeyDown={e => handleKeyDown(e, index, field)}
            className={`w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border text-sm text-slate-100 focus:outline-none focus:ring-2 transition-all ${
              hasError
                ? 'border-rose-500/80 focus:ring-rose-500/30'
                : 'border-slate-700/80 focus:border-cyan-500 focus:ring-cyan-500/20'
            }`}
          >
            {field.options?.map(opt => (
              <option key={opt} value={opt} className="bg-slate-900 text-slate-200">
                {opt}
              </option>
            ))}
          </select>
        );

      case 'checkbox':
        return (
          <div className="flex items-center gap-3 py-2">
            <input
              type="checkbox"
              id={field.id}
              ref={el => { inputRefs.current[field.id] = el; }}
              checked={Boolean(value)}
              onChange={e => handleFieldChange(field.id, e.target.checked)}
              onKeyDown={e => handleKeyDown(e, index, field)}
              className="w-5 h-5 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-500/40 focus:ring-offset-0 cursor-pointer"
            />
            <label htmlFor={field.id} className="text-sm font-medium text-slate-300 cursor-pointer select-none">
              {field.placeholder || `Enable ${field.label}`}
            </label>
          </div>
        );

      case 'textarea':
        return (
          <textarea
            ref={el => { inputRefs.current[field.id] = el; }}
            value={value}
            rows={2}
            placeholder={field.placeholder || 'Type here...'}
            onChange={e => handleFieldChange(field.id, e.target.value)}
            onKeyDown={e => {
              if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                handleSubmit();
              }
            }}
            className={`w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 resize-none transition-all ${
              hasError
                ? 'border-rose-500/80 focus:ring-rose-500/30'
                : 'border-slate-700/80 focus:border-cyan-500 focus:ring-cyan-500/20'
            }`}
          />
        );

      case 'currency':
      case 'number':
        return (
          <div className="relative flex items-center">
            {field.prefix && (
              <span className="absolute left-3.5 text-slate-400 font-mono text-sm pointer-events-none">
                {field.prefix}
              </span>
            )}
            <input
              type="number"
              step={field.type === 'currency' ? '0.01' : '1'}
              min={field.min}
              max={field.max}
              ref={el => { inputRefs.current[field.id] = el; }}
              value={value}
              placeholder={field.placeholder || (field.type === 'currency' ? '0.00' : '0')}
              onChange={e => handleFieldChange(field.id, e.target.value)}
              onKeyDown={e => handleKeyDown(e, index, field)}
              className={`w-full ${field.prefix ? 'pl-8' : 'pl-3.5'} ${
                field.suffix ? 'pr-12' : 'pr-3.5'
              } py-2.5 rounded-lg bg-slate-900 border text-sm font-mono tabular-nums text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                hasError
                  ? 'border-rose-500/80 focus:ring-rose-500/30'
                  : 'border-slate-700/80 focus:border-cyan-500 focus:ring-cyan-500/20'
              }`}
            />
            {field.suffix && (
              <span className="absolute right-3.5 text-slate-500 text-xs font-mono pointer-events-none">
                {field.suffix}
              </span>
            )}
          </div>
        );

      case 'date':
        return (
          <div className="relative flex items-center">
            <input
              type="date"
              ref={el => { inputRefs.current[field.id] = el; }}
              value={value}
              onChange={e => handleFieldChange(field.id, e.target.value)}
              onKeyDown={e => handleKeyDown(e, index, field)}
              className={`w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border text-sm text-slate-100 focus:outline-none focus:ring-2 transition-all ${
                hasError
                  ? 'border-rose-500/80 focus:ring-rose-500/30'
                  : 'border-slate-700/80 focus:border-cyan-500 focus:ring-cyan-500/20'
              }`}
            />
          </div>
        );

      default:
        // text, email, phone, etc.
        return (
          <input
            type={field.type === 'email' ? 'email' : field.type === 'phone' ? 'tel' : 'text'}
            ref={el => { inputRefs.current[field.id] = el; }}
            value={value}
            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}...`}
            onChange={e => handleFieldChange(field.id, e.target.value)}
            onKeyDown={e => handleKeyDown(e, index, field)}
            className={`w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
              hasError
                ? 'border-rose-500/80 focus:ring-rose-500/30'
                : 'border-slate-700/80 focus:border-cyan-500 focus:ring-cyan-500/20'
            }`}
          />
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Rapid Form Entry Card */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
            {/* Top Bar inside Form */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-slate-800/80 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white tracking-tight">
                    {schema.name}
                  </h2>
                  <span className="text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                    Fast-Entry Mode
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Press <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-800 border border-slate-700 rounded text-slate-300">Enter</kbd> to advance field,{' '}
                  <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-800 border border-slate-700 rounded text-cyan-300 font-semibold">Ctrl + Enter</kbd> to save & create next.
                </p>
              </div>

              {recentRecords.length > 0 && (
                <button
                  type="button"
                  onClick={handleDuplicateLast}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-300 hover:text-white transition-colors"
                >
                  <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Duplicate Last Entry</span>
                </button>
              )}
            </div>

            {/* Input Form Fields */}
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {schema.fields.map((field, idx) => {
                  const isFullWidth = field.type === 'textarea' || field.id === schema.primaryFieldId;
                  const isSticky = !!stickyFields[field.id];
                  const errorMsg = errors[field.id];

                  return (
                    <div
                      key={field.id}
                      className={isFullWidth ? 'md:col-span-2' : 'md:col-span-1'}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                          <span>{field.label}</span>
                          {field.required && (
                            <span className="text-rose-400 font-bold" title="Required field">*</span>
                          )}
                        </label>

                        {/* Sticky Toggle Pin */}
                        <button
                          type="button"
                          onClick={() => toggleSticky(field.id)}
                          title={isSticky ? 'Pinned: Value will carry over to next entry' : 'Click to pin value for consecutive entries'}
                          className={`flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded transition-all ${
                            isSticky
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium'
                              : 'text-slate-500 hover:text-slate-300'
                          }`}
                        >
                          <Pin className={`w-3 h-3 ${isSticky ? 'fill-amber-400 rotate-45' : ''}`} />
                          <span className="hidden sm:inline">{isSticky ? 'Pinned' : 'Pin'}</span>
                        </button>
                      </div>

                      {renderFieldInput(field, idx)}

                      {errorMsg && (
                        <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 flex-shrink-0" />
                          <span>{errorMsg}</span>
                        </p>
                      )}

                      {field.helperText && !errorMsg && (
                        <p className="mt-1 text-[11px] text-slate-500">{field.helperText}</p>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Form Action Controls */}
              <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Ready for input</span>
                  </div>
                  {sessionCount > 0 && (
                    <span className="text-slate-500">
                      • {sessionCount} records added this session
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      const blank: Record<string, any> = {};
                      schema.fields.forEach(f => {
                        blank[f.id] = f.defaultValue !== undefined ? f.defaultValue : (f.type === 'checkbox' ? false : '');
                      });
                      setFormData(blank);
                      setErrors({});
                      focusFirstField();
                    }}
                    className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800/50 hover:bg-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
                  >
                    Clear Form
                  </button>

                  <button
                    type="submit"
                    className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-semibold shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-95"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Save Record</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/30 border border-white/20">
                      Ctrl+↵
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* Rapid Tip Banner */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-3.5 flex items-start gap-3 text-xs text-slate-400">
            <div className="p-1 rounded bg-cyan-500/10 text-cyan-400 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="font-semibold text-slate-200">Pro Tip for Maximum Speed:</p>
              <p className="mt-0.5 text-slate-400 leading-relaxed">
                Keep both hands on the keyboard! Type your values and tap <strong className="text-slate-200">Enter</strong> to jump to the next field. When finished, tap <strong className="text-slate-200">Ctrl + Enter</strong> to commit and immediately clear for the next entry. Pin frequent values like Date or Category to never re-type them.
              </p>
            </div>
          </div>
        </div>

        {/* Right Sidebar: Recent Entries Stream & Quick Stats */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Recent Entries ({recentRecords.length})
                </h3>
              </div>
              <button
                onClick={onViewGrid}
                className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
              >
                <span>View Full Grid</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {recentRecords.length === 0 ? (
              <div className="py-8 text-center text-slate-500">
                <p className="text-xs">No records logged yet for this dataset.</p>
                <p className="text-[11px] mt-1 text-slate-600">Enter your first record on the left!</p>
              </div>
            ) : (
              <div className="mt-3 divide-y divide-slate-800/60 max-h-[480px] overflow-y-auto pr-1">
                {recentRecords.slice(0, 8).map((record, index) => {
                  const primaryVal = record.data[schema.primaryFieldId] || 'Unnamed Record';
                  const isJustSaved = lastSavedId === String(primaryVal);

                  return (
                    <div
                      key={record.id}
                      className={`py-3 flex items-start justify-between gap-3 group transition-colors ${
                        isJustSaved ? 'bg-cyan-950/20 rounded-lg px-2 -mx-2' : ''
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-xs text-slate-200 truncate group-hover:text-cyan-300 transition-colors">
                            {primaryVal}
                          </span>
                          {index === 0 && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20">
                              LATEST
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-[11px] text-slate-400">
                          {schema.fields.slice(1, 4).map(f => {
                            const val = record.data[f.id];
                            if (val === undefined || val === '') return null;
                            return (
                              <span key={f.id} className="truncate max-w-[140px]">
                                <span className="text-slate-500">{f.label}:</span>{' '}
                                <span className="text-slate-300 font-mono">
                                  {f.type === 'currency' ? `$${Number(val).toFixed(2)}` : String(val)}
                                </span>
                              </span>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => {
                            setFormData({ ...record.data });
                            focusFirstField();
                            playSound('next', soundEnabled);
                          }}
                          title="Load this record into form"
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 transition-colors"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteRecord(record.id)}
                          title="Delete record"
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
