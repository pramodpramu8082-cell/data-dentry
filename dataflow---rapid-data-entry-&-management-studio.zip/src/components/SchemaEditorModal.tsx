import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Save, 
  Layers, 
  Sliders, 
  AlertCircle,
  HelpCircle,
  Type,
  Hash,
  DollarSign,
  Calendar,
  List,
  Mail,
  Phone,
  CheckSquare,
  AlignLeft
} from 'lucide-react';
import { SchemaDefinition, FieldDefinition, FieldType } from '../types/dataEntry';

interface SchemaEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSchema: SchemaDefinition;
  onSaveSchema: (schema: SchemaDefinition) => void;
  onCreateNewSchema: (schema: SchemaDefinition) => void;
}

export const SchemaEditorModal: React.FC<SchemaEditorModalProps> = ({
  isOpen,
  onClose,
  activeSchema,
  onSaveSchema,
  onCreateNewSchema,
}) => {
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [name, setName] = useState(activeSchema.name);
  const [description, setDescription] = useState(activeSchema.description);
  const [icon, setIcon] = useState(activeSchema.icon);
  const [fields, setFields] = useState<FieldDefinition[]>([...activeSchema.fields]);
  const [primaryFieldId, setPrimaryFieldId] = useState(activeSchema.primaryFieldId);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddField = () => {
    const newId = `field_${Date.now()}`;
    const newField: FieldDefinition = {
      id: newId,
      label: 'New Field',
      type: 'text',
      required: false,
      placeholder: '',
    };
    setFields([...fields, newField]);
  };

  const handleUpdateField = (index: number, updates: Partial<FieldDefinition>) => {
    setFields(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], ...updates };
      return copy;
    });
  };

  const handleRemoveField = (index: number) => {
    if (fields.length <= 1) {
      setError('A schema must have at least one field');
      return;
    }
    const removedField = fields[index];
    const newFields = fields.filter((_, i) => i !== index);
    setFields(newFields);
    if (primaryFieldId === removedField.id && newFields.length > 0) {
      setPrimaryFieldId(newFields[0].id);
    }
  };

  const handleSave = () => {
    if (!name.trim()) {
      setError('Please provide a name for the dataset');
      return;
    }
    if (fields.length === 0) {
      setError('Please configure at least one field');
      return;
    }

    if (isCreatingNew) {
      const newSchemaId = `custom_${Date.now()}`;
      const newSchema: SchemaDefinition = {
        id: newSchemaId,
        name: name.trim(),
        description: description.trim() || 'Custom data entry form',
        icon: icon || 'Database',
        color: '#0284c7',
        fields,
        primaryFieldId: primaryFieldId || fields[0].id,
      };
      onCreateNewSchema(newSchema);
    } else {
      const updatedSchema: SchemaDefinition = {
        ...activeSchema,
        name: name.trim(),
        description: description.trim(),
        icon,
        fields,
        primaryFieldId: primaryFieldId || fields[0].id,
      };
      onSaveSchema(updatedSchema);
    }

    onClose();
  };

  const startCreatingNew = () => {
    setIsCreatingNew(true);
    setName('New Custom Form');
    setDescription('Custom data entry template');
    setIcon('Database');
    setFields([
      { id: 'code', label: 'Reference / Code', type: 'text', required: true, placeholder: 'REF-001' },
      { id: 'title', label: 'Title / Subject', type: 'text', required: true, placeholder: 'Entry title' },
      { id: 'category', label: 'Category', type: 'select', required: true, options: ['General', 'Priority', 'Archive'], defaultValue: 'General' },
      { id: 'date', label: 'Date', type: 'date', required: true, defaultValue: new Date().toISOString().split('T')[0], stickyDefault: true },
    ]);
    setPrimaryFieldId('code');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isCreatingNew ? 'Create New Custom Dataset Form' : `Customize: ${activeSchema.name}`}
              </h3>
              <p className="text-xs text-slate-400">
                Define the form fields, validation rules, and input types.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isCreatingNew && (
              <button
                type="button"
                onClick={startCreatingNew}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold border border-slate-700 transition-colors"
              >
                + Create New Form
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Form Meta */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Dataset / Form Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => { setName(e.target.value); setError(null); }}
                placeholder="e.g. Daily Quality Checks"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Primary Identifier Field
              </label>
              <select
                value={primaryFieldId}
                onChange={e => setPrimaryFieldId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
              >
                {fields.map(f => (
                  <option key={f.id} value={f.id}>
                    {f.label} ({f.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Description / Purpose
              </label>
              <input
                type="text"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Brief explanation for data entry operators..."
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Fields Configuration List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Configured Fields ({fields.length})
              </h4>
              <button
                type="button"
                onClick={handleAddField}
                className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Field</span>
              </button>
            </div>

            <div className="space-y-3">
              {fields.map((field, idx) => (
                <div
                  key={field.id}
                  className="bg-slate-950/40 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 group"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-slate-500 bg-slate-900 px-2 py-0.5 rounded">
                        #{idx + 1}
                      </span>
                      <input
                        type="text"
                        value={field.label}
                        onChange={e => handleUpdateField(idx, { label: e.target.value })}
                        placeholder="Field Label"
                        className="font-semibold text-sm text-white bg-transparent border-b border-transparent hover:border-slate-700 focus:border-cyan-500 focus:outline-none px-1 py-0.5"
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={field.required}
                          onChange={e => handleUpdateField(idx, { required: e.target.checked })}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-500"
                        />
                        <span>Required</span>
                      </label>

                      <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer" title="Value will carry over to next entry by default">
                        <input
                          type="checkbox"
                          checked={!!field.stickyDefault}
                          onChange={e => handleUpdateField(idx, { stickyDefault: e.target.checked })}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-amber-500"
                        />
                        <span className="text-amber-400/90">Sticky Pin</span>
                      </label>

                      <button
                        type="button"
                        onClick={() => handleRemoveField(idx)}
                        className="p-1 rounded text-slate-500 hover:text-rose-400 transition-colors"
                        title="Delete field"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-900">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Type</label>
                      <select
                        value={field.type}
                        onChange={e => {
                          const newType = e.target.value as FieldType;
                          const updates: Partial<FieldDefinition> = { type: newType };
                          if (newType === 'currency') updates.prefix = '$';
                          if (newType === 'select' && !field.options) {
                            updates.options = ['Option A', 'Option B', 'Option C'];
                            updates.defaultValue = 'Option A';
                          }
                          handleUpdateField(idx, updates);
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none"
                      >
                        <option value="text">Text (General)</option>
                        <option value="number">Number</option>
                        <option value="currency">Currency ($)</option>
                        <option value="date">Date</option>
                        <option value="select">Dropdown / Select</option>
                        <option value="email">Email</option>
                        <option value="phone">Phone</option>
                        <option value="checkbox">Checkbox (Yes/No)</option>
                        <option value="textarea">Long Text / Notes</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Placeholder</label>
                      <input
                        type="text"
                        value={field.placeholder || ''}
                        onChange={e => handleUpdateField(idx, { placeholder: e.target.value })}
                        placeholder="e.g. Type something..."
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none"
                      />
                    </div>

                    {field.type === 'select' ? (
                      <div>
                        <label className="text-[11px] text-slate-400 block mb-1">
                          Options (comma separated)
                        </label>
                        <input
                          type="text"
                          value={field.options?.join(', ') || ''}
                          onChange={e => {
                            const opts = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                            handleUpdateField(idx, { options: opts, defaultValue: opts[0] || '' });
                          }}
                          placeholder="Option 1, Option 2, Option 3"
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none"
                        />
                      </div>
                    ) : (
                      <div>
                        <label className="text-[11px] text-slate-400 block mb-1">
                          {field.type === 'currency' ? 'Prefix' : field.type === 'number' ? 'Suffix Unit' : 'Helper Text'}
                        </label>
                        <input
                          type="text"
                          value={field.prefix || field.suffix || field.helperText || ''}
                          onChange={e => {
                            if (field.type === 'currency') handleUpdateField(idx, { prefix: e.target.value });
                            else if (field.type === 'number') handleUpdateField(idx, { suffix: e.target.value });
                            else handleUpdateField(idx, { helperText: e.target.value });
                          }}
                          placeholder={field.type === 'currency' ? '$' : field.type === 'number' ? 'units, kg, pcs' : 'Optional hint'}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none"
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-semibold transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{isCreatingNew ? 'Create & Activate Dataset' : 'Save Form Changes'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
