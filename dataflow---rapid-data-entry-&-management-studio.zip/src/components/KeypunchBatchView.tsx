import React, { useState, useEffect, useRef } from 'react';
import { 
  Zap, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft, 
  RotateCcw, 
  Timer, 
  Trophy, 
  Sparkles,
  Check,
  AlertCircle,
  Play,
  Pause,
  Layers,
  Flame
} from 'lucide-react';
import { SchemaDefinition, DataRecord, FieldDefinition } from '../types/dataEntry';
import { validateFieldValue, validateRecord } from '../utils/exportImport';
import { playSound } from '../utils/audio';

interface KeypunchBatchViewProps {
  schema: SchemaDefinition;
  onSaveRecord: (recordData: Record<string, any>) => void;
  soundEnabled: boolean;
  onViewGrid: () => void;
}

export const KeypunchBatchView: React.FC<KeypunchBatchViewProps> = ({
  schema,
  onSaveRecord,
  soundEnabled,
  onViewGrid,
}) => {
  // Batch session settings
  const [targetBatchSize, setTargetBatchSize] = useState(15);
  const [completedInBatch, setCompletedInBatch] = useState(0);
  const [activeFieldIndex, setActiveFieldIndex] = useState(0);
  const [currentRecordData, setCurrentRecordData] = useState<Record<string, any>>({});
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [currentError, setCurrentError] = useState<string | null>(null);
  const [batchCompleted, setBatchCompleted] = useState(false);

  // Field input ref
  const activeInputRef = useRef<HTMLInputElement | HTMLSelectElement | null>(null);

  // Initialize record data
  useEffect(() => {
    resetRecordState();
    setSessionStartTime(Date.now());
    setCompletedInBatch(0);
    setBatchCompleted(false);
  }, [schema.id]);

  // Elapsed timer ticker
  useEffect(() => {
    if (!isTimerRunning || batchCompleted) return;
    const interval = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isTimerRunning, batchCompleted]);

  // Focus active field input on change
  useEffect(() => {
    if (activeInputRef.current) {
      activeInputRef.current.focus();
      if ('select' in activeInputRef.current && typeof activeInputRef.current.select === 'function') {
        activeInputRef.current.select();
      }
    }
  }, [activeFieldIndex]);

  const resetRecordState = () => {
    const initial: Record<string, any> = {};
    schema.fields.forEach(f => {
      initial[f.id] = f.defaultValue !== undefined ? f.defaultValue : (f.type === 'checkbox' ? false : '');
    });
    setCurrentRecordData(initial);
    setActiveFieldIndex(0);
    setCurrentError(null);
  };

  const currentField: FieldDefinition = schema.fields[activeFieldIndex] || schema.fields[0];
  const currentValue = currentRecordData[currentField.id] !== undefined ? currentRecordData[currentField.id] : '';

  const handleFieldValueChange = (val: any) => {
    setCurrentRecordData(prev => ({
      ...prev,
      [currentField.id]: val,
    }));
    const err = validateFieldValue(currentField, val);
    if (!err) setCurrentError(null);
  };

  const advanceToNextField = () => {
    const err = validateFieldValue(currentField, currentValue);
    if (err) {
      setCurrentError(err);
      playSound('error', soundEnabled);
      return;
    }

    // Check if we are on the last field of this record
    if (activeFieldIndex < schema.fields.length - 1) {
      setActiveFieldIndex(prev => prev + 1);
      playSound('next', soundEnabled);
    } else {
      // Record complete: commit!
      commitCurrentRecord();
    }
  };

  const stepBackField = () => {
    if (activeFieldIndex > 0) {
      setActiveFieldIndex(prev => prev - 1);
      setCurrentError(null);
      playSound('next', soundEnabled);
    }
  };

  const commitCurrentRecord = () => {
    // Validate entire record
    const allErrors = validateRecord(schema, currentRecordData);
    if (Object.keys(allErrors).length > 0) {
      setCurrentError(Object.values(allErrors)[0]);
      playSound('error', soundEnabled);
      return;
    }

    onSaveRecord(currentRecordData);
    playSound('success', soundEnabled);
    const newCount = completedInBatch + 1;
    setCompletedInBatch(newCount);

    if (newCount >= targetBatchSize) {
      setBatchCompleted(true);
      playSound('complete', soundEnabled);
    } else {
      resetRecordState();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      advanceToNextField();
    } else if (e.key === 'ArrowUp' && (e.ctrlKey || e.altKey)) {
      e.preventDefault();
      stepBackField();
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      commitCurrentRecord();
    }
  };

  // Speed calculations
  const minutesElapsed = Math.max(elapsedSeconds / 60, 0.05);
  const recordsPerHour = Math.round((completedInBatch / minutesElapsed) * 60);
  const progressPercent = Math.min(100, Math.round((completedInBatch / targetBatchSize) * 100));

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (batchCompleted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400 mb-4 shadow-lg shadow-emerald-500/20">
            <Trophy className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Batch Target Reached!</h2>
          <p className="text-slate-400 text-sm mt-1">
            You successfully punched all {targetBatchSize} records in {formatTimer(elapsedSeconds)}.
          </p>

          <div className="grid grid-cols-3 gap-3 my-6">
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Total Records</span>
              <span className="text-xl font-bold font-mono text-emerald-400">{completedInBatch}</span>
            </div>
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Session Time</span>
              <span className="text-xl font-bold font-mono text-cyan-400">{formatTimer(elapsedSeconds)}</span>
            </div>
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-500 uppercase tracking-wider block">Entry Velocity</span>
              <span className="text-xl font-bold font-mono text-amber-400">{recordsPerHour}/hr</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                setBatchCompleted(false);
                setCompletedInBatch(0);
                setElapsedSeconds(0);
                resetRecordState();
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 hover:from-blue-500 hover:to-cyan-400 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Start Another Batch</span>
            </button>
            <button
              onClick={onViewGrid}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-2 transition-all"
            >
              <span>Inspect Records in Grid</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Session HUD Top Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 mb-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Head-Down Keypunch HUD
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/20">
                PUNCH MODE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Record <span className="text-white font-mono font-bold">{completedInBatch + 1}</span> of {targetBatchSize} Target
            </p>
          </div>
        </div>

        {/* Live Metrics */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <Timer className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-300">{formatTimer(elapsedSeconds)}</span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-amber-400 font-bold">{recordsPerHour}</span>
            <span className="text-slate-500 text-[10px]">rec/hr</span>
          </div>

          <select
            value={targetBatchSize}
            onChange={e => setTargetBatchSize(Number(e.target.value))}
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
            title="Batch Target Goal"
          >
            <option value={10}>Batch Goal: 10</option>
            <option value={15}>Batch Goal: 15</option>
            <option value={25}>Batch Goal: 25</option>
            <option value={50}>Batch Goal: 50</option>
          </select>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span>Batch Progress</span>
          <span className="font-mono text-cyan-400 font-semibold">{progressPercent}%</span>
        </div>
        <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-300 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Giant Focused Input Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative">
        {/* Step indicator header */}
        <div className="flex items-center justify-between pb-6 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-cyan-500/10 text-cyan-400 font-bold border border-cyan-500/20">
              FIELD {activeFieldIndex + 1} OF {schema.fields.length}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {currentField.label} {currentField.required && <span className="text-rose-400">*</span>}
            </span>
          </div>

          <span className="text-xs font-mono text-slate-500">
            Tap <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">Enter</kbd> to punch next
          </span>
        </div>

        {/* Big Active Input Field */}
        <div className="py-8">
          <div className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            Punch value for:
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white mb-4">
            {currentField.label}
          </div>

          {currentField.type === 'select' ? (
            <select
              ref={el => { activeInputRef.current = el; }}
              value={currentValue}
              onChange={e => handleFieldValueChange(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full text-xl sm:text-2xl px-5 py-4 rounded-2xl bg-slate-950 border-2 border-cyan-500/60 focus:border-cyan-400 focus:outline-none text-white font-medium shadow-inner"
            >
              {currentField.options?.map(opt => (
                <option key={opt} value={opt} className="bg-slate-900 text-slate-100 text-base">
                  {opt}
                </option>
              ))}
            </select>
          ) : currentField.type === 'checkbox' ? (
            <div className="flex items-center gap-4 py-4">
              <input
                type="checkbox"
                id="batch-checkbox"
                ref={el => { activeInputRef.current = el; }}
                checked={Boolean(currentValue)}
                onChange={e => handleFieldValueChange(e.target.checked)}
                onKeyDown={handleKeyDown}
                className="w-8 h-8 rounded-lg border-2 border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0 cursor-pointer"
              />
              <label htmlFor="batch-checkbox" className="text-lg font-medium text-slate-200 cursor-pointer">
                {currentField.placeholder || `Check to enable ${currentField.label}`}
              </label>
            </div>
          ) : (
            <div className="relative">
              {currentField.prefix && (
                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-2xl font-mono text-slate-500 pointer-events-none">
                  {currentField.prefix}
                </span>
              )}
              <input
                ref={el => { activeInputRef.current = el; }}
                type={currentField.type === 'number' || currentField.type === 'currency' ? 'number' : currentField.type === 'date' ? 'date' : 'text'}
                step={currentField.type === 'currency' ? '0.01' : '1'}
                value={currentValue}
                placeholder={currentField.placeholder || `Type ${currentField.label.toLowerCase()}...`}
                onChange={e => handleFieldValueChange(e.target.value)}
                onKeyDown={handleKeyDown}
                className={`w-full text-xl sm:text-2xl ${
                  currentField.prefix ? 'pl-12' : 'px-5'
                } py-4 rounded-2xl bg-slate-950 border-2 ${
                  currentError ? 'border-rose-500/80 focus:border-rose-400' : 'border-cyan-500/60 focus:border-cyan-400'
                } focus:outline-none text-white font-mono shadow-inner tracking-wide transition-all`}
              />
            </div>
          )}

          {currentError && (
            <p className="mt-3 text-sm text-rose-400 flex items-center gap-1.5 font-medium">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{currentError}</span>
            </p>
          )}

          {currentField.helperText && !currentError && (
            <p className="mt-2 text-xs text-slate-500">{currentField.helperText}</p>
          )}
        </div>

        {/* Bottom controls */}
        <div className="pt-6 border-t border-slate-800 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={stepBackField}
            disabled={activeFieldIndex === 0}
            className={`px-4 py-2.5 rounded-xl border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeFieldIndex === 0
                ? 'opacity-40 cursor-not-allowed text-slate-600'
                : 'text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous Field</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={advanceToNextField}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-sm shadow-xl shadow-cyan-500/25 flex items-center gap-2 transition-all transform active:scale-95"
            >
              <span>{activeFieldIndex === schema.fields.length - 1 ? 'Save Record' : 'Next Field'}</span>
              {activeFieldIndex === schema.fields.length - 1 ? (
                <Check className="w-4 h-4" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/30 border border-white/20 ml-1">
                ↵
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Field Checklist Breadcrumbs */}
      <div className="mt-6 flex flex-wrap items-center gap-2">
        {schema.fields.map((f, i) => {
          const isDone = i < activeFieldIndex;
          const isCurrent = i === activeFieldIndex;
          return (
            <button
              key={f.id}
              onClick={() => setActiveFieldIndex(i)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1 ${
                isCurrent
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : isDone
                  ? 'bg-slate-800 text-emerald-400 hover:bg-slate-750'
                  : 'bg-slate-900/60 text-slate-500 hover:text-slate-400 border border-slate-800'
              }`}
            >
              {isDone && <Check className="w-3 h-3 text-emerald-400" />}
              <span>{f.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
