import React, { useMemo } from 'react';
import { 
  X, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Trash2, 
  Eye, 
  Sparkles 
} from 'lucide-react';
import { SchemaDefinition, DataRecord } from '../types/dataEntry';
import { validateRecord } from '../utils/exportImport';

interface DataHygieneModalProps {
  isOpen: boolean;
  onClose: () => void;
  schema: SchemaDefinition;
  records: DataRecord[];
  onDeleteRecord: (id: string) => void;
}

export const DataHygieneModal: React.FC<DataHygieneModalProps> = ({
  isOpen,
  onClose,
  schema,
  records,
  onDeleteRecord,
}) => {
  if (!isOpen) return null;

  // Find duplicate primary field values
  const duplicates = useMemo(() => {
    const valueMap: Record<string, DataRecord[]> = {};
    const primaryId = schema.primaryFieldId;

    records.forEach(r => {
      const val = String(r.data[primaryId] || '').trim().toLowerCase();
      if (val) {
        if (!valueMap[val]) valueMap[val] = [];
        valueMap[val].push(r);
      }
    });

    const dupesList: { value: string; records: DataRecord[] }[] = [];
    Object.entries(valueMap).forEach(([val, list]) => {
      if (list.length > 1) {
        dupesList.push({ value: val, records: list });
      }
    });

    return dupesList;
  }, [schema.primaryFieldId, records]);

  // Find records with validation errors or missing required fields
  const invalidRecords = useMemo(() => {
    const issues: { record: DataRecord; errors: Record<string, string> }[] = [];
    records.forEach(r => {
      const errs = validateRecord(schema, r.data);
      if (Object.keys(errs).length > 0) {
        issues.push({ record: r, errors: errs });
      }
    });
    return issues;
  }, [schema, records]);

  const hasIssues = duplicates.length > 0 || invalidRecords.length > 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl ${hasIssues ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'} flex items-center justify-center`}>
              {hasIssues ? <ShieldAlert className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Data Quality & Duplicate Audit</h3>
              <p className="text-xs text-slate-400">Automated hygiene check for {schema.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {!hasIssues ? (
            <div className="py-12 text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-white">100% Clean Data</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                No duplicate {schema.fields.find(f => f.id === schema.primaryFieldId)?.label || 'identifier'} entries or missing required values were found across all {records.length} records.
              </p>
            </div>
          ) : (
            <>
              {/* Duplicates Section */}
              {duplicates.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Duplicate Identifiers Detected ({duplicates.length})
                    </h4>
                  </div>
                  <div className="space-y-2">
                    {duplicates.map(dupe => (
                      <div
                        key={dupe.value}
                        className="bg-slate-950/60 border border-amber-500/20 rounded-xl p-3"
                      >
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="font-mono font-bold text-amber-300">
                            "{dupe.value}"
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-mono">
                            {dupe.records.length} duplicates
                          </span>
                        </div>
                        <div className="divide-y divide-slate-800/60">
                          {dupe.records.map((r, i) => (
                            <div key={r.id} className="py-1.5 flex items-center justify-between text-xs text-slate-400">
                              <span className="truncate max-w-xs">
                                Row #{i + 1} • Created {new Date(r.createdAt).toLocaleDateString()}
                              </span>
                              <button
                                onClick={() => onDeleteRecord(r.id)}
                                className="text-rose-400 hover:text-rose-300 flex items-center gap-1 text-[11px]"
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>Remove</span>
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Missing Fields Section */}
              {invalidRecords.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Incomplete or Invalid Records ({invalidRecords.length})
                    </h4>
                  </div>
                  <div className="space-y-2">
                    {invalidRecords.map(item => (
                      <div
                        key={item.record.id}
                        className="bg-slate-950/60 border border-rose-500/20 rounded-xl p-3 flex items-start justify-between gap-3 text-xs"
                      >
                        <div>
                          <span className="font-semibold text-slate-200">
                            {String(item.record.data[schema.primaryFieldId] || 'Unnamed Record')}
                          </span>
                          <div className="mt-1 space-y-0.5">
                            {Object.entries(item.errors).map(([fId, err]) => (
                              <p key={fId} className="text-rose-400 text-[11px]">
                                • {err}
                              </p>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => onDeleteRecord(item.record.id)}
                          className="p-1 rounded text-slate-500 hover:text-rose-400"
                          title="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
