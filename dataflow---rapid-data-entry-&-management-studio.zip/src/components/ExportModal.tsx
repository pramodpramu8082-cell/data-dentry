import React, { useState } from 'react';
import { 
  X, 
  FileDown, 
  FileSpreadsheet, 
  Code, 
  Printer, 
  Copy, 
  Check, 
  Sparkles 
} from 'lucide-react';
import { SchemaDefinition, DataRecord } from '../types/dataEntry';
import { exportToCSV, downloadFile } from '../utils/exportImport';
import { playSound } from '../utils/audio';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  schema: SchemaDefinition;
  records: DataRecord[];
  soundEnabled: boolean;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  schema,
  records,
  soundEnabled,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleDownloadCSV = () => {
    const csvContent = exportToCSV(schema, records);
    const fileName = `${schema.id}_export_${new Date().toISOString().split('T')[0]}.csv`;
    downloadFile(csvContent, fileName, 'text/csv;charset=utf-8;');
    playSound('success', soundEnabled);
  };

  const handleDownloadJSON = () => {
    const jsonContent = JSON.stringify(
      records.map(r => ({
        id: r.id,
        createdAt: r.createdAt,
        ...r.data,
      })),
      null,
      2
    );
    const fileName = `${schema.id}_export_${new Date().toISOString().split('T')[0]}.json`;
    downloadFile(jsonContent, fileName, 'application/json');
    playSound('success', soundEnabled);
  };

  const handleCopyTSVForExcel = () => {
    // Generate tab-separated values so user can paste directly into Excel / Google Sheets
    const headers = schema.fields.map(f => f.label).join('\t');
    const rows = records.map(r => schema.fields.map(f => String(r.data[f.id] || '')).join('\t'));
    const tsv = [headers, ...rows].join('\n');

    navigator.clipboard.writeText(tsv);
    setCopied(true);
    playSound('next', soundEnabled);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <FileDown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Export Dataset</h3>
              <p className="text-xs text-slate-400">Export {records.length} records from {schema.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Export Options */}
        <div className="p-6 space-y-3">
          <button
            onClick={handleDownloadCSV}
            className="w-full p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-emerald-500/50 flex items-center justify-between group transition-all text-left"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">
                  CSV Spreadsheet (.csv)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Compatible with Microsoft Excel, Google Sheets, Airtable, & Databases
                </p>
              </div>
            </div>
            <FileDown className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
          </button>

          <button
            onClick={handleDownloadJSON}
            className="w-full p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-blue-500/50 flex items-center justify-between group transition-all text-left"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
                <Code className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                  JSON Data (.json)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Structured JSON array for developers, APIs, & programmatic imports
                </p>
              </div>
            </div>
            <FileDown className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
          </button>

          <button
            onClick={handleCopyTSVForExcel}
            className="w-full p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-cyan-500/50 flex items-center justify-between group transition-all text-left"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                <Copy className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {copied ? 'Copied to Clipboard!' : 'Copy to Clipboard (Paste in Excel)'}
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Tab-separated raw table for immediate paste into open spreadsheet apps
                </p>
              </div>
            </div>
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-500 group-hover:text-cyan-400" />}
          </button>

          <button
            onClick={handlePrint}
            className="w-full p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-purple-500/50 flex items-center justify-between group transition-all text-left"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-purple-400 transition-colors">
                  Print Report / PDF
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Opens browser print view formatted cleanly for physical paper or PDF save
                </p>
              </div>
            </div>
            <Printer className="w-4 h-4 text-slate-500 group-hover:text-purple-400 transition-colors" />
          </button>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
