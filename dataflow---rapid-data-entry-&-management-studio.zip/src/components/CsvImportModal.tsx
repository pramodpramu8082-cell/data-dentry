import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  ArrowRight, 
  Check, 
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { SchemaDefinition, DataRecord } from '../types/dataEntry';
import { parseCSV } from '../utils/exportImport';
import { playSound } from '../utils/audio';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  schema: SchemaDefinition;
  onImportRecords: (newRecords: DataRecord[], replaceExisting: boolean) => void;
  soundEnabled: boolean;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  schema,
  onImportRecords,
  soundEnabled,
}) => {
  const [csvRaw, setCsvRaw] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<string[][]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  // Mapping: schemaFieldId -> csvHeaderIndex
  const [columnMapping, setColumnMapping] = useState<Record<string, number>>({});
  const [replaceExisting, setReplaceExisting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      processCsvText(text);
    };
    reader.readAsText(file);
  };

  const processCsvText = (text: string) => {
    try {
      const rows = parseCSV(text);
      if (rows.length < 2) {
        setError('CSV must have a header row and at least 1 data row.');
        return;
      }

      const headers = rows[0];
      const dataRows = rows.slice(1);

      setCsvRaw(text);
      setCsvHeaders(headers);
      setParsedRows(dataRows);
      setError(null);

      // Auto-map columns: match schema field label or id to CSV header
      const autoMap: Record<string, number> = {};
      schema.fields.forEach(field => {
        const fieldNameLower = field.label.toLowerCase();
        const fieldIdLower = field.id.toLowerCase();

        const matchIdx = headers.findIndex(h => {
          const hLower = h.toLowerCase();
          return hLower === fieldNameLower || hLower === fieldIdLower || hLower.includes(fieldNameLower) || fieldNameLower.includes(hLower);
        });

        if (matchIdx !== -1) {
          autoMap[field.id] = matchIdx;
        }
      });

      setColumnMapping(autoMap);
    } catch {
      setError('Failed to parse CSV file. Ensure valid comma-delimited format.');
    }
  };

  const handleExecuteImport = () => {
    if (parsedRows.length === 0) {
      setError('No data rows to import.');
      return;
    }

    const createdRecords: DataRecord[] = parsedRows.map((row, idx) => {
      const data: Record<string, any> = {};

      schema.fields.forEach(field => {
        const mappedIdx = columnMapping[field.id];
        if (mappedIdx !== undefined && row[mappedIdx] !== undefined) {
          let val: any = row[mappedIdx];
          if (field.type === 'number' || field.type === 'currency') {
            const cleanNum = String(val).replace(/[\$,]/g, '').trim();
            val = cleanNum === '' ? '' : Number(cleanNum);
          } else if (field.type === 'checkbox') {
            val = ['true', 'yes', '1', 'y'].includes(String(val).toLowerCase().trim());
          }
          data[field.id] = val;
        } else {
          data[field.id] = field.defaultValue !== undefined ? field.defaultValue : (field.type === 'checkbox' ? false : '');
        }
      });

      return {
        id: `import_${Date.now()}_${idx}`,
        schemaId: schema.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        data,
      };
    });

    onImportRecords(createdRecords, replaceExisting);
    playSound('success', soundEnabled);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Import Records into {schema.name}</h3>
              <p className="text-xs text-slate-400">Upload a CSV spreadsheet file to bulk populate rows</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {parsedRows.length === 0 ? (
            <div className="border-2 border-dashed border-slate-800 hover:border-cyan-500/50 rounded-2xl p-8 text-center transition-colors">
              <FileSpreadsheet className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-300">Choose a CSV file to import</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Upload your comma-separated spreadsheet. Columns will be auto-matched with your dataset schema.
              </p>

              <label className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer shadow-lg shadow-cyan-500/20 transition-all">
                <Upload className="w-4 h-4" />
                <span>Select CSV File</span>
                <input
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-xs">
                <span className="text-slate-300">
                  Detected <strong className="text-cyan-400 font-mono">{parsedRows.length}</strong> data rows and{' '}
                  <strong className="text-cyan-400 font-mono">{csvHeaders.length}</strong> columns.
                </span>
                <label className="text-cyan-400 hover:underline cursor-pointer">
                  Change File
                  <input
                    type="file"
                    accept=".csv,text/csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Column Mapping Section */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Match Schema Fields to CSV Columns
                </h4>
                <div className="space-y-2 bg-slate-950/40 p-3 rounded-2xl border border-slate-800">
                  {schema.fields.map(field => (
                    <div key={field.id} className="flex items-center justify-between text-xs py-1">
                      <span className="text-slate-300 font-medium">
                        {field.label} {field.required && <span className="text-rose-400">*</span>}
                      </span>
                      <div className="flex items-center gap-2">
                        <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                        <select
                          value={columnMapping[field.id] !== undefined ? columnMapping[field.id] : -1}
                          onChange={e => {
                            const val = Number(e.target.value);
                            setColumnMapping(prev => ({
                              ...prev,
                              [field.id]: val === -1 ? undefined! : val,
                            }));
                          }}
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                        >
                          <option value={-1}>-- Skip / Leave Blank --</option>
                          {csvHeaders.map((header, idx) => (
                            <option key={idx} value={idx}>
                              Column {idx + 1}: {header}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id="replace-existing"
                  checked={replaceExisting}
                  onChange={e => setReplaceExisting(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-rose-500"
                />
                <label htmlFor="replace-existing" className="text-xs text-slate-400 cursor-pointer">
                  Replace all existing records in this dataset (leave unchecked to append)
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
          >
            Cancel
          </button>

          {parsedRows.length > 0 && (
            <button
              type="button"
              onClick={handleExecuteImport}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Import {parsedRows.length} Records</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
