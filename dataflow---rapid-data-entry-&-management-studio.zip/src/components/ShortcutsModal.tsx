import React from 'react';
import { X, Keyboard, Command } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    {
      group: 'Form Entry Navigation',
      items: [
        { keys: ['Enter'], desc: 'Advance to next input field (plays tactile click)' },
        { keys: ['Ctrl', 'Enter'], desc: 'Save record, clear form, and focus first field' },
        { keys: ['Cmd', 'Enter'], desc: 'Save record on Mac' },
        { keys: ['Tab'], desc: 'Standard tab navigation forward' },
        { keys: ['Shift', 'Tab'], desc: 'Navigate to previous input field' },
      ],
    },
    {
      group: 'View Navigation',
      items: [
        { keys: ['Alt', '1'], desc: 'Switch to Rapid Single Form view' },
        { keys: ['Alt', '2'], desc: 'Switch to Head-Down Keypunch Batch view' },
        { keys: ['Alt', '3'], desc: 'Switch to Spreadsheet Data Grid view' },
      ],
    },
    {
      group: 'Spreadsheet Grid Mode',
      items: [
        { keys: ['Double Click'], desc: 'Edit cell inline' },
        { keys: ['Enter'], desc: 'Commit cell changes' },
        { keys: ['Escape'], desc: 'Cancel editing cell or close active modal' },
      ],
    },
    {
      group: 'General & Ergonomics',
      items: [
        { keys: ['?'], desc: 'Toggle keyboard shortcuts reference' },
        { keys: ['Esc'], desc: 'Dismiss active modal dialog' },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Keyboard Shortcuts</h3>
              <p className="text-xs text-slate-400">Master rapid data keypunching without touching the mouse</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {shortcuts.map((group, gIdx) => (
            <div key={gIdx} className="space-y-2">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                {group.group}
              </h4>
              <div className="bg-slate-950/60 rounded-2xl border border-slate-800/80 divide-y divide-slate-800/60">
                {group.items.map((item, iIdx) => (
                  <div key={iIdx} className="p-3 flex items-center justify-between text-xs gap-3">
                    <span className="text-slate-300 font-medium">{item.desc}</span>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {item.keys.map((k, kIdx) => (
                        <kbd
                          key={kIdx}
                          className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 font-mono text-[11px] shadow-sm"
                        >
                          {k}
                        </kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
