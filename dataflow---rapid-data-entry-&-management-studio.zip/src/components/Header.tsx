import React from 'react';
import { 
  Database, 
  Layers, 
  TableProperties, 
  Zap, 
  Plus, 
  FileDown, 
  Upload, 
  ShieldAlert, 
  Volume2, 
  VolumeX, 
  Keyboard, 
  RotateCcw,
  Sparkles,
  Package,
  Receipt,
  Users,
  Activity,
  FileSpreadsheet
} from 'lucide-react';
import { SchemaDefinition, ViewMode } from '../types/dataEntry';

interface HeaderProps {
  schemas: SchemaDefinition[];
  activeSchemaId: string;
  onSelectSchema: (id: string) => void;
  viewMode: ViewMode;
  onSetViewMode: (mode: ViewMode) => void;
  recordCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenSchemaEditor: () => void;
  onOpenImportModal: () => void;
  onOpenExportModal: () => void;
  onOpenHygieneModal: () => void;
  onOpenShortcutsModal: () => void;
  onResetData: () => void;
  sessionRecordCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  schemas,
  activeSchemaId,
  onSelectSchema,
  viewMode,
  onSetViewMode,
  recordCount,
  soundEnabled,
  onToggleSound,
  onOpenSchemaEditor,
  onOpenImportModal,
  onOpenExportModal,
  onOpenHygieneModal,
  onOpenShortcutsModal,
  onResetData,
  sessionRecordCount,
}) => {
  const activeSchema = schemas.find(s => s.id === activeSchemaId) || schemas[0];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Package': return <Package className="w-4 h-4" />;
      case 'Receipt': return <Receipt className="w-4 h-4" />;
      case 'Users': return <Users className="w-4 h-4" />;
      case 'Activity': return <Activity className="w-4 h-4" />;
      default: return <Database className="w-4 h-4" />;
    }
  };

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
      {/* Top Banner Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold">
            <Database className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
                DataFlow <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono border border-cyan-500/20">Studio v2.4</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Rapid Keyboard-Driven Data Entry & Management
            </p>
          </div>
        </div>

        {/* Global Action Tools */}
        <div className="flex items-center gap-2">
          {sessionRecordCount > 0 && (
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              <span>+{sessionRecordCount} entered this session</span>
            </div>
          )}

          <button
            onClick={onToggleSound}
            title={soundEnabled ? "Tactile Audio: On (Click to Mute)" : "Tactile Audio: Muted (Click to Enable)"}
            className={`p-2 rounded-lg border text-xs font-medium transition-all ${
              soundEnabled
                ? 'bg-slate-800/80 border-slate-700 text-cyan-400 hover:bg-slate-800'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-400'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenShortcutsModal}
            title="Keyboard Shortcuts (Press ?)"
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white transition-all text-xs flex items-center gap-1.5"
          >
            <Keyboard className="w-4 h-4" />
            <span className="hidden lg:inline text-xs font-mono text-slate-400">Keys</span>
          </button>

          <button
            onClick={onOpenHygieneModal}
            title="Data Quality & Duplicate Audit"
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white transition-all text-xs flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span className="hidden lg:inline text-xs text-slate-300">Audit</span>
          </button>

          <div className="h-4 w-px bg-slate-800 hidden sm:block"></div>

          <button
            onClick={onOpenImportModal}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Import</span>
          </button>

          <button
            onClick={onOpenExportModal}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <FileDown className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Export</span>
          </button>

          <button
            onClick={onResetData}
            title="Reset to Demo Data"
            className="p-2 rounded-lg bg-slate-800/40 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Subheader: Schema Selector & View Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-col md:flex-row md:items-center justify-between gap-3 border-t border-slate-800/60 bg-slate-950/40">
        {/* Schemas List Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1 hidden sm:inline">
            Dataset:
          </span>
          {schemas.map((s) => {
            const isSelected = s.id === activeSchemaId;
            return (
              <button
                key={s.id}
                onClick={() => onSelectSchema(s.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-slate-800 text-white shadow-sm border border-slate-700 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                <span className="text-cyan-400">{getIcon(s.icon)}</span>
                <span>{s.name}</span>
              </button>
            );
          })}

          <button
            onClick={onOpenSchemaEditor}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 border border-dashed border-slate-700/80 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Customize Form</span>
          </button>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center justify-between sm:justify-end gap-3">
          <div className="flex items-center bg-slate-900 border border-slate-800 p-0.5 rounded-lg text-xs">
            <button
              onClick={() => onSetViewMode('form')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                viewMode === 'form'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Rapid Form</span>
            </button>

            <button
              onClick={() => onSetViewMode('batch')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                viewMode === 'batch'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Keypunch Batch</span>
            </button>

            <button
              onClick={() => onSetViewMode('grid')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                viewMode === 'grid'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TableProperties className="w-3.5 h-3.5" />
              <span>Data Grid</span>
              <span className="text-[10px] ml-0.5 px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 font-mono">
                {recordCount}
              </span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
